#include <iostream>
#include"Binary_node.h"
using namespace std;
template <class Entry>
class Binary_tree{
public:
	/* Binary_tree constructor */ 
	Binary_tree();
		
	void print_inorder(Binary_node<Entry> *sub_root);
	void print_preorder(Binary_node<Entry> *sub_root);
	
	Binary_node<Entry> *root;

};

template <class Entry>
Binary_tree<Entry>::Binary_tree()
{
	root = NULL;
}

template <class Entry>
void Binary_tree<Entry>::print_inorder(Binary_node<Entry> *sub_root)
{
	if (sub_root != NULL)
	{		
		print_inorder(sub_root->left);
		cout<<sub_root->data<<" ";
		print_inorder(sub_root->right);
	}
}

template <class Entry>
void Binary_tree<Entry>::print_preorder(Binary_node<Entry> *sub_root)
{
	if (sub_root != NULL)
	{
		cout<<sub_root->data<<" ";
		print_preorder(sub_root->left);
		print_preorder(sub_root->right);
	}
}
