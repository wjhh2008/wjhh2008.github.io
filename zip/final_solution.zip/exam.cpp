#include "Binary_tree.h"
#include <iostream>
using namespace std;

int n, k;
int node_for_get_parent;
int preorder[100], inorder[100];
Binary_tree<int> btree;

int build_tree(Binary_node<int> * &sub_root, int l, int r)
{
	int tmp_rt = preorder[k++];
	int i;

	for (i = l; i <= r; i++)
	{
		if (inorder[i] == tmp_rt) break;	
	}
	if (inorder[i] != tmp_rt) return -1; //error
	//cout<<"tmp_rt="<<tmp_rt<<"  i="<<i<<endl;
	if (sub_root == NULL) sub_root = new Binary_node<int>(tmp_rt);
	if (i > l) 
	{
		if (-1 == build_tree(sub_root->left, l, i-1))
			return -1;
	}
	if (i < r) 
	{
		if (-1 == build_tree(sub_root->right, i+1, r))
			return -1;
	}
	return 0;
}

// [prob 1]
int get_parent(Binary_node<int> * root, int key)
{
	int parent_key = -1;
	//your code here 
	
	if (root->left != NULL)
	{
		 if (root->left->data == key)
		 {
		 	parent_key = root->data;
		 }
		 else
		 {
		 	parent_key = get_parent(root->left, key);
		 }
	}
	if (root->right != NULL && parent_key == -1)
	{
		 if (root->right->data == key)
		 {
		 	parent_key = root->data;
		 }
		 else
		 {
		 	parent_key = get_parent(root->right, key);
		 }
	}

	return parent_key;
} 

// [prob 2]
bool sort_tree_or_not(Binary_node<int> * root)
{
	//your code here 
	bool sort_tree = true;
	if (root->left != NULL)
	{
		 if (root->left->data > root->data)
		 {
		 	sort_tree = false;
		 }
		 sort_tree &= sort_tree_or_not(root->left);
	}
	if (root->right != NULL)
	{
		 if (root->right->data < root->data)
		 {
		 	sort_tree = false;
		 }
		 sort_tree &= sort_tree_or_not(root->right);
	}
	return sort_tree;
}

// [prob 3]
void exchange_left_and_right_and_print(Binary_node<int> * root)
{
	//your code here
	if (root != NULL)
	{
		 exchange_left_and_right_and_print(root->left);
		 exchange_left_and_right_and_print(root->right);
		 Binary_node<int>* tmp = root->left;
		 root->left = root->right;
		 root->right = tmp; 
	}
	
	return;
}

int main(int argc, char** argv) 
{	
	//get the preorder and the inorder of a tree
	cin>>n;
	for (int i=0; i<n; i++)
	{
		cin>>preorder[i];
	}
	for (int i=0; i<n; i++)
	{
		cin>>inorder[i];
	}
	
	//building Tree
	k = 0;
	cout<<(build_tree(btree.root, 0, n-1)==0?"Building Tree Success.":"Build Tree Error.")<<endl;
	
	//Test start
	cout<<"Test Start : "<<endl;
	
	// [prob 1]  get_parent() test 
	cout<<"Test 1"<<endl;
	cout<<"-----------------------------"<<endl;
	cout<<"Input a key : ";
	cin>>node_for_get_parent;
	
	cout<<"The parent of key("<<node_for_get_parent<<") is :\tkey("<<get_parent(btree.root, node_for_get_parent)<<")"<<endl<<endl;
	
	// [prob 2] sort_tree_or_not() test 
	cout<<"Test 2"<<endl;
	cout<<"-----------------------------"<<endl;
	
	cout<<"Is a sort tree? : \t\t"<<(sort_tree_or_not(btree.root)==1?"YES":"NO")<<endl<<endl;
	
	// [prob 3] exchange_left_and_right_and_print() test 
	cout<<"Test 3"<<endl;
	cout<<"-----------------------------"<<endl;
	
	exchange_left_and_right_and_print(btree.root);
		
	cout<<"The preorder is : \t\t";
	btree.print_preorder(btree.root);  //print the preorder 
	cout<<endl;
	cout<<"The inorder is : \t\t";
	btree.print_inorder(btree.root);   //print the inorder 
	cout<<endl;
	
	
	//Test end	
	return 0;
}

/*

1��	���һ������x�ڶ������е�˫�׽���㷨��
���룺 rootָ�룬key x
�����x�ĸ��ڵ�key

2��	�ж϶������Ƿ�Ϊ�������������㷨
���룺 rootָ��
�����true or false

3. ���������������н�������������㷨��
���룺 rootָ��
����� ����֮��Ķ����� 


��Ŀ��֤����û���ظ���keyֵ
 
*/

/*
Sample input:

4
10 20 30 40
20 10 40 30
40

Sample output:

4
10 20 30 40
20 10 40 30
Building Tree Success.
Test Start :
Test 1
-----------------------------
Input a key : 40
The parent of key(40) is :      key(30)

Test 2
-----------------------------
Is a sort tree? :               NO

Test 3
-----------------------------
The preorder is :               10 30 40 20
The inorder is :                30 40 10 20

*/

/*
Explain:

the tree will be built like:
       10
     /   \
   20    30
  / \    / \
nul nul	40  nul

for test1:
the parent of 40 is 30

for test2:
if the tree is a sort tree, the answer is no.

for test3:
after exchanging, the tree will be like:
       10
     /   \
   30    20
  / \    / \
nul 40 nul nul

so the preorder is :  10 30 40 20
so the inorder is :  30 40 10 20
  
*/
